myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))

name = input("What is your name? ")
print("Hello, " + name + "!")

color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you smell like a {} {}!".format(name,color,animal))